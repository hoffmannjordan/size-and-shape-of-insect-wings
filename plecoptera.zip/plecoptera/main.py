##import modules
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from scipy import ndimage
import scipy as sp
import scipy.ndimage
from scipy import ndimage
from skimage import measure
import skfmm
import glob
from mpi4py import MPI

def rgb_to_gray(rgb):
	r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
	gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
	return gray

def rgba_to_gray(rgb):
	r, g, b,a = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2],rgb[:,:,3]
	gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
	return gray

def binarize_data(data,thresh):
	return (data > thresh)

def connected_comp(matrix):
	L = sp.ndimage.measurements.label(matrix)[0]
	maxv = np.amax(L)
	perm = np.random.permutation(range(1,maxv+3))
	dup = np.zeros(np.shape(L))
	print np.shape(L)
	dim1,dim2 = np.shape(L)
	for i in xrange(dim1):
		for j in xrange(dim2):
			if L[i][j] != 0:
				dup[i][j] = perm[L[i][j]]
	# plt.imshow(dup,cmap='nipy_spectral',interpolation='none')
	# plt.savefig('./'+'tmp'+'.png', dpi=300,bbox_inches='tight')
	# plt.clf()
	# exit()
	return dup

def import_data(name,cutoff):
	im = Image.open(name)
	imarray = np.array(im)
	dims = np.shape(imarray)
	#make sure the image is the right dimensions
	if len(dims) == 3 and dims[2] == 3:
		imarray = rgb_to_gray(imarray)
	elif len(dims) == 3 and dims[2] == 4:
		imarray = rgba_to_gray(imarray)
	else:
		print 'Dimension error.'
		exit() 
	#imarray = rgb2gray(imarray)
	imarray = scipy.ndimage.filters.gaussian_filter(imarray,1.0)
	print np.shape(imarray)
	dim1,dim2 = np.shape(imarray)
	data = np.zeros((dim1,dim2))
	for i in xrange(dim1):
		for j in xrange(dim2):
			data[i][j] = 1-imarray[i][j]
	data += np.abs(np.amin(data))
	data = data/np.amax(data)
	tmp = np.zeros(np.shape(data))
	for i in xrange(dim1):
		for j in xrange(dim2):
			if data[i][j] > cutoff:
				tmp[i][j] = 1.0
	return tmp

def by_size(mat,thresh):
	maxv = np.amax(mat)
	locs = [[] for i in xrange(int(maxv))]
	dim1,dim2 = np.shape(mat)
	for i in xrange(dim1):
		for j in xrange(dim2):
			if int(mat[i][j]) != 0:
				locs[int(mat[i][j]-1)].append([i,j])
	centroids = []
	for i in xrange(len(locs)):
		if len(locs[i])>thresh:
			xs,ys = np.transpose(np.array(locs[i]))
			dx = np.amax(xs) - np.amin(xs)
			dy = np.amax(ys) - np.amin(ys)
			if dx > 1000 and dy > 1000:
				a = range(len(xs))
				a = np.random.permutation(a)
				for j in xrange(5000):
					centroids.append([ys[a[j]],xs[a[j]]])
			else:
				cx = np.mean(xs)
				cy = np.mean(ys)
				centroids.append([cy,cx]) 
	xt = np.transpose(centroids)[0]
	yt = np.transpose(centroids)[1]
	return np.array(centroids)

def expand(i,j,tmp3,dx,dy):
	toreturn=[]
	if i < (dx-1) and tmp3[i+1][j] == 0:
		toreturn.append((i+1,j))
	if j<(dy-1) and tmp3[i][j+1] == 0:
		toreturn.append((i,j+1))
	if i > 0 and tmp3[i-1][j] == 0:
		toreturn.append((i-1,j))
	if j > 0 and tmp3[i][j-1] == 0:
		toreturn.append((i,j-1))
	return toreturn

def segment_wing(cx,cy,dx,dy,dz,times,name):
	iterator = 0
	file_counter = 0
	x = np.arange(0, dy)
	y = np.arange(0, dx)
	X, Y = np.meshgrid(x, y)
	tmp = np.zeros((dx,dy))
	shuffler = range(len(cx))
	shuffler = np.random.permutation(shuffler)
	for i in xrange(len(cx)):
		tmp[cy[i]][cx[i]] = shuffler[i]+1
	todo = []
	for i in xrange(len(cx)):
		todo.append(expand(int(cy[i]),int(cx[i]),tmp,dx,dy))
	tmin= np.amin(times)
	tmax= np.amax(times)
	t = 0
	dt = 0.025
	while t< tmax+1:
		#pbar.update(t)
		tmp2 = np.copy(tmp)
		lens = [ len(list(set(todo[i]))) for i in xrange(len(todo))]
		tmp_list = [[] for i in xrange(len(cx))]
		shuffler_for_order = range(len(cx))
		shuffler_for_order = np.random.permutation(shuffler_for_order)
		for ii in range(len(cx)):
			i = shuffler_for_order[ii]
			list_to_do = list(set(todo[i]))
			if list_to_do != []:
				for j in xrange(len(list_to_do)):
					if times[list_to_do[j][0],list_to_do[j][1]] < t and tmp[list_to_do[j][0],list_to_do[j][1]]==0:
						tmp[list_to_do[j][0],list_to_do[j][1]] = shuffler[i]+1
						addon = expand(list_to_do[j][0],list_to_do[j][1],tmp2,dx,dy)
						if addon != []:
							for k in range(len(addon)):
								tmp_list[i].append(addon[k])
					elif times[list_to_do[j][0],list_to_do[j][1]] > t:
						tmp[list_to_do[j][0],list_to_do[j][1]] = 0
						tmp_list[i].append(list_to_do[j])
		todo = tmp_list[:]
		iterator += 1
		t+=dt
		if iterator%1450 == 0:
			#print m,t,tmax
			np.savetxt('./Segmented_'+str(name)+'.csv',tmp.astype(int),fmt='%i',delimiter=',')
	np.savetxt('./Segmented_'+str(name)+'.csv',tmp.astype(int),fmt='%i',delimiter=',')
	#pbar.finish()


if __name__=='__main__':
	comm = MPI.COMM_WORLD
	size = comm.Get_size()
	rank = comm.Get_rank()
	#Define variables
	#image = './top.png' #file path to the image
	all_to_do = glob.glob('./*png')
	len_todo = len(all_to_do)
	delta = len_todo/size
	start = rank*delta
	stop = start + delta
	if rank == size-1:
		stop = len_todo
	print start,stop
	#exit()
	print all_to_do
	for kk in range(start,stop):#all_to_do:
		image = all_to_do[kk]
		bin_thresh = 0.83
		#functions to run
		data = import_data(image , 0.05)
		velocity = 1-data
		objects = connected_comp(1-data)
		min_size = 1
		cs = by_size(objects,min_size)
		print cs
		wing_name = image.split('.')[1].split('/')[1]
		print 'Wing name is: ',wing_name
		print 'Now you have the centroids!'
		##segmentation part of the code
		cx,cy = np.transpose(cs)
		a,b = np.shape(data)
		fmm = np.ones((a, b))
		for i in xrange(len(cx)):
			x1 = int(cx[i])
			y1 = int(cy[i])
			fmm[y1][x1] = -1
		dist_mat = skfmm.distance(fmm)
		speed = velocity + 0.01
		#you might need to play with these two numbers
		speed=scipy.ndimage.filters.gaussian_filter(speed,1.0)
		# plt.imshow(speed,cmap='hot')
		# plt.show()
		t = skfmm.travel_time(fmm, speed)
		# plt.imshow(t,cmap='gnuplot2')
		# plt.show()
		print 'Starting segmentation'
		segment_wing(cx,cy,a,b,1,t,wing_name)
		print 'ALL DONE WITH STEP 1'
