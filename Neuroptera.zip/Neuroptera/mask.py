import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import glob

def rgb_to_gray(rgb):
	r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
	gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
	return gray

def rgba_to_gray(rgb):
	r, g, b,a = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2],rgb[:,:,3]
	gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
	return gray

def import_data(name):
	im = Image.open(name)
	imarray = np.array(im)
	dims = np.shape(imarray)
	#make sure the image is the right dimensions
	if len(dims) == 3 and dims[2] == 3:
		imarray = rgb_to_gray(imarray)
	elif len(dims) == 3 and dims[2] == 4:
		imarray = rgba_to_gray(imarray)
	else:
		print 'Dimension error.'
		exit() 
	return imarray

def create_tmp_mask(data):
	tmp = 1.0*(data<240)
	return tmp

def breadth_search(start_positionx, start_positiony):
	a,b = np.shape(tmp)
	checked = {}
	to_check = []
	to_check.append([start_positionx, start_positiony])
	while len(to_check) != 0:
		next_to_checkx, next_to_checky = to_check.pop(0)
		if not (checked.get(tuple([next_to_checkx, next_to_checky]), None)) and (tmp[next_to_checkx, next_to_checky] == 0):
		#if [next_to_checkx, next_to_checky] not in checked:
			if next_to_checkx+1 < a:
				to_check.append([next_to_checkx+1, next_to_checky])
			if next_to_checky+1 < b:
				to_check.append([next_to_checkx, next_to_checky+1])
			if next_to_checkx-1 >= 0:
				to_check.append([next_to_checkx-1, next_to_checky])
			if next_to_checky-1 >= 0:
				to_check.append([next_to_checkx, next_to_checky-1])
			checked[tuple([next_to_checkx, next_to_checky])] = True
			tmp2[next_to_checkx, next_to_checky] = 0
			# print "length of to check:", len(to_check)
			# print "length of checked:", len(checked)
	return tmp2

def refine_mask(data,mask):
	mask2 = np.copy(mask)
	xs,ys = np.where(mask == 0)
	tocheck = []
	for i in xrange(len(xs)):
		tocheck.append(data[xs[i]][ys[i]])
	tocheck = np.unique(tocheck)
	dim1 , dim2 = np.shape(data)
	for i in xrange(dim1):
		for j in xrange(dim2):
			if data[i][j] in tocheck:
				mask2[i][j] = 0
	xs,ys = np.where(mask2 == 0)
	return mask2

if __name__=='__main__':
	all_to_do = glob.glob('./*png')
	for image in all_to_do:
		#image = './Chrysop_LFW.png'
		wing_name = image.split('.')[1].split('/')[1]
		data = import_data(image)
		tmp = create_tmp_mask(data)
		#print tmp[0]
		#plt.imshow(tmp)
		#plt.show()
		#exit()
		tmp2 = np.ones(np.shape(data))
		mask = breadth_search(0, 0)
		#plt.imshow(mask)
		#plt.show()
		segmented = 'SEGMENTED_'+wing_name+'.csv'
		dat = np.genfromtxt(segmented,delimiter=',')
		ref_mask = refine_mask(dat,mask)
		data = dat*ref_mask
		#plt.imshow(data,cmap='nipy_spectral')
		#plt.show()
		np.savetxt('./MASKED_'+wing_name+'.csv',data.astype(int),fmt='%i',delimiter=',')
		#exit()
